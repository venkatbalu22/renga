<header class="fixed_header menu_v4 submenu_version">
        <div class="layer"></div><!-- Opacity Mask -->
        <div class="container">
            <div class="row align-items-center">
                <div class="col-3">
                    <a href="home" class="logo_normal"><img src="image\logo\logo-white.png" width="165" height="75" alt=""></a>
                    <a href="home" class="logo_sticky"><img src="image\logo\logo.png" width="165" height="75" alt=""></a>
                </div>
                <div class="col-9">
                    <div class="main-menu">
                        <a href="#" class="closebt open_close_menu"><i class="bi bi-x"></i></a>
                        <div class="logo_panel"><img src="http://www.ansonika.com/paradise/img/logo_sticky.png" width="135" height="45" alt=""></div>
                        <nav id="mainNav">
                            <ul>
                                 <li class="submenu">
                                    <a href="home" >Home</a>
                                    <!-- <ul>
                                        <li><a href="http://www.ansonika.com/paradise/index.html">Home Video Bg</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/index-2.html">Home Carousel</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/index-3.html">Home FlexSlider</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/index-4.html">Home Youtube/Vimeo</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/index-5.html">Home Parallax</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/index-6.html">Home Parallax 2</a></li>
                                    </ul> -->
                                </li>
                                <li class="submenu">
                                     <a href="room" >Rooms & Suites</a>
                                    <!-- <ul>
                                        <li><a href="http://www.ansonika.com/paradise/room-list-1.html">Room list 1</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/room-list-2.html">Room list 2</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/room-list-3.html">Room list 3</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/room-details.html">Room details</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/room-details-booking.html">Working Booking Request</a></li>
                                    </ul> -->
                                </li>
                                <!-- <li class="submenu"> 
                                    <a href="#0" class="show-submenu">Other Pages</a>
                                    <ul>
                                        <li><a href="http://www.ansonika.com/paradise/gallery.html">Masonry Gallery</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/restaurant.html">Restaurant</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/menu-of-the-day.html">Menu of the day</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/news-1.html">Blog</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/404.html">Error Page</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/modal-advertise-1.html">Modal Advertise</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/cookie-bar.html">GDPR Cookie Bar</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/coming-soon.html">Coming Soon</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/menu-2.html">Menu Version 2 <span class="custom_badge">Hot</span></a></li>
                                        <li><a href="http://www.ansonika.com/paradise/menu-3.html">Menu Version 3</a></li>
                                        <li><a href="http://www.ansonika.com/paradise/menu-4.html">Menu Version 4</a></li>
                                    </ul> 
                                </li> -->
                                <li><a href="about">About Us</a></li>
                                <li><a href="contacts">Contacts Us</a></li>
                                <!-- <li><a href="#booking_section" class="btn_1">Book Now</a></li> -->
                            </ul>
                        </nav>
                    </div>
                    <div class="hamburger_2 open_close_menu float-end">
                        <div class="hamburger__box">
                            <div class="hamburger__inner"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- container -->
    </header><!-- End Header -->